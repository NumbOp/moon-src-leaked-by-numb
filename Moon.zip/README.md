## 🤖 FORK
[![Run on Repl.it](https://repl.it/badge/github/Adivise/DisSpaceX)](https://repl.it/github/Adivise/DisSpaceX)

## 📑 Short Feature
- [x] Music
- [x] Filters
- [x] MessageButton
- [x] No Database Requirement
- [x] Easy to use

## 🎶 Support Source
- [x] Youtube
- [x] SoundCloud
- [x] Spotify

## 🚨 Have a Problem

✈ Join Discord:  [NanoSpace ♪♪](https://discord.gg/SNG3dh3MbR)
   mention me in chat #general or #javascript and ask problem okay! 👌

## 🛑 Requirements

Node.js V16+ **[Download](https://nodejs.org/dist/v17.0.1/node-v17.0.1-x64.msi)**

Discord Bot Token **[Guide](https://discordjs.guide/preparations/setting-up-a-bot-application.html#creating-your-bot)**

FFmpeg **[Download](https://github.com/BtbN/FFmpeg-Builds)**

## 💌 Installation

```
git clone https://github.com/Adivise/DisSpaceX
cd DisSpaceX
npm install
```
After installation finishes you can use `node .` to start the bot. or `Run Start.bat`

## 📚 Configuration

Copy or Rename `.env.example` to `.env` and fill out the values:

```.env
TOKEN=replace_on_here
PREFIX=!
OWNER_ID-replace_on_here
```

## 📄 Features & Commands

> Note: The default prefix is '#'

🎶 **Music Commands!** 
- Play (#play, #p, #pplay) can play song from youtube, soundcloud and spotify
- Nowplaying (#nowplaying, #np)
- Queue (#queue <page>, #q <page>)
- Loop (#loop, #l)
- Loopqueue (#loopqueue, #lq)
- Shuffle (#shuffle)
- Volume control (#vol)
- Pause (#pause, #pa)
- Resume (#resume, #re)
- Skip (#skip, #s)
- Skipto (#skipto, #st)
- Join (#join, #cmon, summon)
- Leave (#leave, #dc, #lev, #stop)

⏺ **Filter Commands!**
- Vaporwave (#vaporwave, #vw)
- earwax (#earwax)
- Nightcore (#nightcore, nc)
- 3d (#3d) <== use head phone for this feeling
- echo (#echo)
- flanger (#flanger, #fg)
- gate (#gate)
- haas (#hass)
- karaoke (#kk, #karaoke)
- mcopand (#mp, #mcopand)
- phaser (#phaser)
- reverse (#reverse)
- surround (#sr, #surround)
- tremolo (#tremolo)
- Bassboost (#bb, #bassboost)
- Reset (#reset)

📑 **Utilities Commands!**
- FilterList (#fl, #filterlist)
- Help (#help, #h, #halp, #commands)
- Invite (#invite)
- Restart (#restart, #stopbot, #shutdown)

## 🖼 Picture

- [CLICK ME!](https://imgur.com/a/zvP3NIi)

![see](https://i.imgur.com/03KM8sq.png)
![see](https://i.imgur.com/lr4whgX.png)
![see](https://i.imgur.com/Uv1JX4f.png)
![see](https://i.imgur.com/CqKhn2a.png)
![see](https://i.imgur.com/sbkZXnb.png)
![see](https://i.imgur.com/4GGIXyZ.png)
![see](https://i.imgur.com/poraMNP.png)

