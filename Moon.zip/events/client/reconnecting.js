const chalk = require("chalk");

module.exports = client => {
    console.log(chalk.yellow(`[${message.guild.me.displayName}] || Reconnceting at ${new Date()}.`))
}
